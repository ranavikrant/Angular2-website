import { Component, EventEmitter } from '@angular/core';
import {AdvertisementForm} from './component/AdvertisementForm/AdvertisementForm.component';
import{templateDriven} from './component/TDF/TemplateDriven.component';
import {modelDriven} from './component/MDF/ModelDriven.component';
import {formbuilder} from './component/Formbuilder/Formbuilder.component';
import { ProductService } from './Services/product.service';
@Component({
  selector: 'my-app',
  template: `<myForm (postedAdEvent)="productService.addProducts($event);"></myForm>
            <adtable [ads]="adArray"></adtable>`,
  providers: [ProductService]
})
export class AppComponent  {
    constructor(private productService: ProductService) { //Declaring service dependency
//console.log("Products = ", productService.getProducts());

}
    public adArray: Array<{ name:String, category:String, description:String }> = [];
    
    
}
