import { Injectable } from '@angular/core';
@Injectable()
export class ProductService {
  public adArray1: Array<{ name:String, category:String, description:String }> = [];
getProducts() {
return this.adArray1;
}


addProducts(obj:any) {
this.adArray1.push(obj);
//console.log(this.adArray1);

}

getAd()
{
    return this.adArray1;
}
deleteAd(delAd:any)
{
    let index:number=delAd.index;
    this.adArray1.splice(index,1);
    return this.adArray1;
}
}