import { Component,NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule,FormControl,FormGroup,Validators,FormBuilder} from '@angular/forms';
@Component({
    selector:"Formbuilder-Form",
    templateUrl: './Formbuilder.html',
    styles: [`input.ng-invalid {border-left: 5px solid red} input.ng-valid {border-left: 5px solid green}`]
})
export class formbuilder{
productForm: FormGroup;
constructor(private formBuilder: FormBuilder) {
this.productForm = this.formBuilder.group({
name: ['Anand', [Validators.required, Validators.minLength(3), Validators.maxLength(8)]],
quantity: [], price: [] });
}
}