import { Component,NgModule } from '@angular/core';
import { ProductService } from '../../Services/product.service';


@Component({
    selector:"adtable",
    templateUrl: './AdvertisementTable.component.html',
    
    inputs:['ads'],

})






export class AdvertisementTable{
     constructor(private productService: ProductService) { //Declaring service dependency
}
      getallad()
      {
          return this.productService.getAd();
      }
   
     ads: Array<{ name:String, category:String, description:String }> = [];

    
    deleteAd(ad:any):void{
      //let  index= this.ads.indexOf(ad);
       
     // this.ads.splice(ad,1);}
     this.productService.deleteAd(ad);
   
    
}

