import { Component,NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
@Component({
    selector:"TemplateDriven-Form",
    templateUrl: './TemplateDrivenForm.html',
})
export class templateDriven{

}