import { NgModule, EventEmitter }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { AppComponent }  from './app.component';
import {AdvertisementForm} from './component/AdvertisementForm/AdvertisementForm.component';
import {AdvertisementTable} from './component/AdvertisementForm/AdvertisementTable.component';
import {SearchPipe} from './component/AdvertisementForm/search.component'
import{templateDriven} from './component/TDF/TemplateDriven.component';
import{modelDriven} from './component/MDF/ModelDriven.component';
import {formbuilder} from './component/Formbuilder/Formbuilder.component';
@NgModule({
  imports:      [ BrowserModule,FormsModule,ReactiveFormsModule ],
  declarations: [ AppComponent, AdvertisementForm , AdvertisementTable,SearchPipe,templateDriven,modelDriven,formbuilder],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
