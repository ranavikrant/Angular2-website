"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var forms_1 = require("@angular/forms");
var app_component_1 = require("./app.component");
var AdvertisementForm_component_1 = require("./component/AdvertisementForm/AdvertisementForm.component");
var AdvertisementTable_component_1 = require("./component/AdvertisementForm/AdvertisementTable.component");
var search_component_1 = require("./component/AdvertisementForm/search.component");
var TemplateDriven_component_1 = require("./component/TDF/TemplateDriven.component");
var ModelDriven_component_1 = require("./component/MDF/ModelDriven.component");
var Formbuilder_component_1 = require("./component/Formbuilder/Formbuilder.component");
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [platform_browser_1.BrowserModule, forms_1.FormsModule, forms_1.ReactiveFormsModule],
        declarations: [app_component_1.AppComponent, AdvertisementForm_component_1.AdvertisementForm, AdvertisementTable_component_1.AdvertisementTable, search_component_1.SearchPipe, TemplateDriven_component_1.templateDriven, ModelDriven_component_1.modelDriven, Formbuilder_component_1.formbuilder],
        bootstrap: [app_component_1.AppComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map